package com.cg.daos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bean.Product;

@Repository
public interface PlacedOrderDAO extends JpaRepository<Product, Integer> {

	@Modifying
	@Transactional
	@Query("update Product p set p.quantity =p.quantity-?2, p.soldQuantities = p.soldQuantities+?2 where p.productID=?1")
	public void updateProducts(int pid, int cart_quantity);
}
