package com.cg.controllers;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.services.OrderServices;

@RestController
@RequestMapping(value = "/capstore")
public class PlacedController {

	@Autowired
	OrderServices service;

	@GetMapping(value = "/placingorder/{cartID}")
	public String placeOrder(@PathVariable int cartID) {
		return service.checkProducts(cartID);
	}

	@PutMapping(value = "/payment/{modeOfPurchase}/{cartID}")
	public boolean getPayment(@PathVariable int cartID, @PathVariable String modeOfPurchase) {

		return service.updateInventory(cartID, modeOfPurchase);
	}

}
