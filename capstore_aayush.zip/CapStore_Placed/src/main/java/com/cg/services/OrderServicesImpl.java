package com.cg.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bean.Cart;
import com.cg.bean.Product;
import com.cg.bean.Transaction;
import com.cg.bean.User1;
import com.cg.daos.CartDAO;
import com.cg.daos.PlacedOrderDAO;
import com.cg.daos.TransactionUpdateDAO;
import com.cg.exception.ApplicationException;

@Service
@Transactional
public class OrderServicesImpl implements OrderServices {

	@Autowired
	PlacedOrderDAO placeDao;

	@Autowired
	TransactionUpdateDAO transactDao;

	@Autowired
	CartDAO dao;

	public Product findByProductId(int pid) {

		Optional<Product> product = placeDao.findById(pid);
		if (product.isPresent()) {
			return product.get();
		} else {
			throw new ApplicationException("No Product Exists");
		}
	}

	public Cart findByCartId(int cartID) {

		Optional<Cart> cart = dao.findById(cartID);
		if (cart.isPresent()) {
			return cart.get();
		} else {
			throw new ApplicationException("No Cart Exists");
		}
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public String checkProducts(int cartID) {
		Cart cart = findByCartId(cartID);
		boolean status = false;
		List<Integer[]> products = cart.getProducts();
		String msg="";
		String msg1="";
		for (Integer[] p : products) {
			int pid = p[0];
			int cart_quantity = p[1];
			Product product = findByProductId(pid);

			int quantity = product.getQuantity();
			if (cart_quantity <= quantity) {
				status = true;
				msg1="You can proceed Now";
				continue;
			} else
				status = false;
				msg=product.getProductName()+"is out of Stock";
				break;
		}
		
		if (status)
			return msg1;
		else
			return msg;
	}
	
	@Transactional(propagation = Propagation.REQUIRED)
	public boolean updateProducts(int pid, int cart_quantity) {
		try {
			placeDao.updateProducts(pid, cart_quantity);
		} catch (ApplicationException e) {
			throw new ApplicationException("Can't Update");
		}
		return true;
	}


	@Transactional(propagation = Propagation.REQUIRED)
	public boolean updateInventory(int cartID, String modeOfPurchase) {

		Cart cart = findByCartId(cartID);
		List<Integer[]> products = cart.getProducts();
		boolean updateStatus = false;
		for (Integer[] p : products) {
			int pid = p[0];
			int quantity = p[1];
			updateStatus = updateProducts(pid, quantity);
		}
		List<Integer[]> products1 = new ArrayList<Integer[]>();
		products1.addAll(products);
		if (updateStatus) {
			User1 user = cart.getUser();
			String status = "Ordered";
			Date dateOfPurchase = new Date();

			Transaction transaction = new Transaction();
			transaction.setUser(user);
			transaction.setProducts(products1);
			transaction.setStatus(status);
			transaction.setDateOfPurchase(dateOfPurchase);
			transaction.setModeOfPurchase(modeOfPurchase);

			System.out.println(transaction);
			transactDao.saveAndFlush(transaction);

			return true;
		} else {
			return false;
		}

	}
}
