package com.cg.services;

import com.cg.bean.Cart;
import com.cg.bean.Product;

public interface OrderServices {

	public Product findByProductId(int pid);

	public boolean updateInventory(int cartID, String modeOfPurchase);

	public boolean updateProducts(int pid, int quantity);

	public String checkProducts(int cartID);
	
	public Cart findByCartId(int cartID);
	

}
